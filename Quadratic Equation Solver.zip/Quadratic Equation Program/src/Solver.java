import java.util.Scanner;


import java.util.ArrayList;

public class Solver {
  
  

  public static void main(String[] args) {
    
    Scanner scanner = new Scanner(System.in);
    System.out.println("Welcome to the Quadratic Equation Solver.");
    System.out.println("");
    System.out.println("You must have an equation in the form of ax^2 + bx + c = 0 in order to use this program.");
    System.out.println("");
    System.out.println("This Solver does not currently support equations that generate imaginary numbers.");
    System.out.println("");
    System.out.println("Created by Nicholas Megas on December 13, 2019");
    System.out.println("");
    System.out.println("Version 1.0");
    System.out.println("");
    System.out.println("First, enter the coefficent of a:");
    
    double first = scanner.nextDouble(); 
   
    System.out.println("Enter the coefficent of b:");
    double second = scanner.nextDouble();
    
    System.out.println("Finally,enter the coefficent of c");
    double third = scanner.nextDouble();
    
    
    double[] solution = QuadraticSolver(first, second, third);
    
 
    System.out.println("The solutions to the equation are: " + solution[0] + " and: "+ solution[1]);
  
    scanner.close();
    

  }

  
  public static double[] QuadraticSolver(double a, double b, double c) {
    
    double[] solutions = new double[2];
    
      if (  ((b*b) - (4*a*c) ) < 0 ){
        throw new IllegalArgumentException("Your equation will generate imaginary numbers, please check your coefficents.");
       
      }
    
    
    
    double solution1 =  (   ((-1*b) +  Math.sqrt(  (b*b) - (4*a*c))  )    / (2*a)  );
    double solution2 = (   ((-1*b) -  Math.sqrt(  (b*b) - (4*a*c))  )    / (2*a)  );
    
    solutions[0] = solution1;
    solutions[1] = solution2;
    
    
    return solutions;
    
  }
  
  
}
